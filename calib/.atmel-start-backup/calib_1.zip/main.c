#include <atmel_start.h>
#include <avr/cpufunc.h> 
#include "calib_values.h"

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	NOP();
	CalibInternalRc();
	NOP();
	/* Replace with your application code */
	while (1) {
	}
}
